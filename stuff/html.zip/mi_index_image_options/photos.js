WPGgallery = new Object();
WPGgallery.name = "MI%20INDEX%20IMAGE%20OPTIONS%201";
WPGgallery.photographer = "heidi%20frieder%20:%20:%20art%20head%20:%20:%20903.519.2339";
WPGgallery.contact = "";
WPGgallery.email = "";
WPGgallery.date = "8/29/12"

WPGgallery.colors = new Object();
WPGgallery.colors.background = "#FFFFFF";
WPGgallery.colors.banner = "#FFFFFF";
WPGgallery.colors.text = "#000000";
WPGgallery.colors.link = "#002AC5";
WPGgallery.colors.alink = "#7E8BB8";
WPGgallery.colors.vlink = "#B8B9BE";

gPhotos = new Array();
gPhotos[0] = new Object();
gPhotos[0].filename = "mi_web_index_selection_1.jpg";
gPhotos[0].ImageWidth = 450;
gPhotos[0].ImageHeight = 250;
gPhotos[0].ThumbWidth = 75;
gPhotos[0].ThumbHeight = 41;
gPhotos[0].meta = new Object();

gPhotos[1] = new Object();
gPhotos[1].filename = "mi_web_index_selection_2.jpg";
gPhotos[1].ImageWidth = 450;
gPhotos[1].ImageHeight = 250;
gPhotos[1].ThumbWidth = 75;
gPhotos[1].ThumbHeight = 41;
gPhotos[1].meta = new Object();

gPhotos[2] = new Object();
gPhotos[2].filename = "mi_web_index_selection_3.jpg";
gPhotos[2].ImageWidth = 450;
gPhotos[2].ImageHeight = 250;
gPhotos[2].ThumbWidth = 75;
gPhotos[2].ThumbHeight = 41;
gPhotos[2].meta = new Object();

gPhotos[3] = new Object();
gPhotos[3].filename = "mi_web_index_selection_4.jpg";
gPhotos[3].ImageWidth = 450;
gPhotos[3].ImageHeight = 250;
gPhotos[3].ThumbWidth = 75;
gPhotos[3].ThumbHeight = 41;
gPhotos[3].meta = new Object();

gPhotos[4] = new Object();
gPhotos[4].filename = "mi_web_index_selection_5.jpg";
gPhotos[4].ImageWidth = 450;
gPhotos[4].ImageHeight = 250;
gPhotos[4].ThumbWidth = 75;
gPhotos[4].ThumbHeight = 41;
gPhotos[4].meta = new Object();

gPhotos[5] = new Object();
gPhotos[5].filename = "mi_web_index_selection_6.jpg";
gPhotos[5].ImageWidth = 450;
gPhotos[5].ImageHeight = 250;
gPhotos[5].ThumbWidth = 75;
gPhotos[5].ThumbHeight = 41;
gPhotos[5].meta = new Object();

gPhotos[6] = new Object();
gPhotos[6].filename = "mi_web_index_selection_7.jpg";
gPhotos[6].ImageWidth = 450;
gPhotos[6].ImageHeight = 250;
gPhotos[6].ThumbWidth = 75;
gPhotos[6].ThumbHeight = 41;
gPhotos[6].meta = new Object();


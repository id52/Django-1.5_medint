/*
MenuMachine 2 definition file - do not edit. http://menumachine.com
2.2.1 :: MI_menu_1
*/
var menuName="mi_menu_1";
var pkg=new menuPackage(menuName,0,0,0,0,0,1,0,0,1);
/*s*/
pkg.aB("mb9f87f2","",5.6875,3.625,0,0,0,0,97,97,3,3,0,"v",100,"",0.0625,0.0625,"white",0,"#910202",0,0,"#AAAAAA",0,0,0,"","","","",0,0,0,0,0,0,0,0,0);
pkg.aI("m651cf78","mb9f87f2",5.5625,1.125,0.0625,0.0625,"Our Story","",/*URL*/"../../mi_sandbox_our_story.html","_self","","","",0,0,0,0,"","Our Story",0,0,"Helvetica,Geneva,Arial,SunSans-Regular,sans-serif","","#002ac5",0.8125,1,0,0,"white",0,0,0,0.1875,0.25,"",1,"","","#2b89b1",0.8125,1,0,0,"white",0,0,0,0.1875,0.25,"",1,"","","#002ac5",0.8125,1,0,0,"white",0,0,0,0.1875,0.25,"");
pkg.aI("mf648465","mb9f87f2",5.5625,1.125,0.0625,1.25,"Library","",/*URL*/"../../mi_sandbox_whitepapers.html","_self","","","",0,0,0,0,"","Library",1,1);
pkg.aI("mc00d584","mb9f87f2",5.5625,1.125,0.0625,2.4375,"","","","_self",/*URL*/"../../images/mi_web_sandbox_b_wwr.jpg",/*URL*/"../../images/mi_web_sandbox_b_wwr_roll.jpg",/*URL*/"../../images/mi_web_sandbox_b_wwr.jpg",0,0,0,0,"","Media",2,1);
pkg.aB("mb8ab759","mc00d584",5.6875,4.8125,5.875,2.4375,93,0,97,97,3,3,1);
pkg.aI("m6e65e4c","mb8ab759",5.5625,1.125,0.0625,0.0625,"","","","_self",/*URL*/"../../images/mi_web_sandbox_b_story.jpg",/*URL*/"../../images/mi_web_sandbox_b_story_roll.jpg",/*URL*/"../../images/mi_web_sandbox_b_story.jpg",0,0,0,0,"","News",0,0,"Helvetica,Geneva,Arial,SunSans-Regular,sans-serif","","#002ac5",0.8125,0,0,0,"white",0,0,0,0.1875,0.25,"",1,_,_,_,_,0,_,_,_,_,_,_,_,_,_,1,_,_,_,_,0,_,_,_,_,_,_,_,_,_);
pkg.aI("mdf61048","mb8ab759",5.5625,1.125,0.0625,1.25,"Press Room","","","_self","","","",0,0,0,0,"","Press Room",1,1);
pkg.aI("m9c5ab39","mb8ab759",5.5625,1.125,0.0625,2.4375,"Facebook","","","_self","","","",0,0,0,0,"","Facebook",2,1);
pkg.aI("mf40b276","mb8ab759",5.5625,1.125,0.0625,3.625,"Twitter","","","_self","","","",0,0,0,0,"","Twitter",3,1);
/*f*/
__menuHolder.aP(pkg);
var __l=__br.un?"un.js":(__br.ie?"iedom.js":(__br.dom?"w3cdom.js":""));
document.write(_sTs+mmfolder+"core/"+__l+_sTe);
/*
MenuMachine 2 definition file - do not edit. http://menumachine.com
2.2.1 :: MI_sandbox_footer_links
*/
var menuName="mi_sandbox_bottom_links";
var pkg=new menuPackage(menuName,0,0,0,0,0,1,0,0,1);
/*s*/
pkg.aB("m145e97f","",16.625,1,0,0,0,0,0,0,0,0,0,"h",100,"",0,0,"",0,"black",0,1,"#1a2a9a",0.0625,0.0625,0,"","","","",0,0,0,0,0,0,0,0,0);
pkg.aI("m27pbxz2","m145e97f",4.5,1,0,0,"Contact Us","",/*URL*/"../../mi_sandbox_contact_us.html","","","","",0,0,0,0,"","Contact Us",0,0,"Helvetica,Geneva,Arial,SunSans-Regular,sans-serif","","#002ac5",0.6875,0,0,0,"white",0,1,0,0.375,0.1875,"",1,"","","#2b89b1",0.6875,0,0,0,"white",0,1,0,0.375,0.1875,"",1,"","","#002ac5",0.6875,0,0,0,"white",0,1,0,0.375,0.1875,"");
pkg.aI("m27pbxz3","m145e97f",4.9375,1,4.5625,0,"Terms of Use","",/*URL*/"../../mi_sandbox_legal.html","","","","",0,0,0,0,"","Terms of Use",1,1);
pkg.aI("m27pbxz4","m145e97f",3.25,1,9.5625,0,"Privacy","",/*URL*/"../../mi_sandbox_privacy.html","","","","",0,0,0,0,"","Privacy",2,1);
pkg.aI("m27pbxz5","m145e97f",3.75,1,12.875,0,"About Us","",/*URL*/"../../mi_sandbox_our_story.html","","","","",0,0,0,0,"","Privacy",3,1);
/*f*/
__menuHolder.aP(pkg);
var __l=__br.un?"un.js":(__br.ie?"iedom.js":(__br.dom?"w3cdom.js":""));
document.write(_sTs+mmfolder+"core/"+__l+_sTe);
/*
MenuMachine 2 definition file - do not edit. http://menumachine.com
2.2.1 :: MI_sandbox_menu
*/
var menuName="mi_sandbox_menu";
var pkg=new menuPackage(menuName,0,0,0,0,0,1,0,0,1);
/*s*/
pkg.aB("m236e2b1","",6.1875,3.4375,0,0,0,0,0,0,0,0,0,"v",100,"",0.0625,0.0625,"white",0,"#910202",0,0,"#AAAAAA",0,0,0,"","","","",0,0,0,0,0,0,0,0,0);
pkg.aI("m2db83d5","m236e2b1",6.0625,1.0625,0.0625,0.0625,"Our Story","",/*URL*/"../../mi_sandbox_our_story.html","_self","","","",0,0,0,0,"","Our Story",0,0,"Helvetica,Geneva,Arial,SunSans-Regular,sans-serif","","#002ac5",0.8125,1,0,0,"white",0,0,0,0.1875,0.125,"",1,"","","#2b89b1",0.8125,1,0,0,"white",0,0,0,0.1875,0.125,"",1,"","","#002ac5",0.8125,1,0,0,"white",0,0,0,0.1875,0.125,"");
pkg.aI("m27pbxye","m236e2b1",6.0625,1.0625,0.0625,1.1875,"Library","",/*URL*/"../../mi_sandbox_library.html","_self","","","",0,0,0,0,"","Library",1,1);
pkg.aI("m27pbxyf","m236e2b1",6.0625,1.0625,0.0625,2.3125,"Who We Are","","","_self","","","",0,0,0,0,"","Who We Are",2,1);
pkg.aB("m27pbxyg","m27pbxyf",9.6875,3.4375,6.0625,2.3125,96,0,98,98,3,3,1);
pkg.aI("m27pbxyh","m27pbxyg",9.5625,1.0625,0.0625,0.0625,"Board of Directors","",/*URL*/"../../mi_sandbox_board_of_directors.html","_self","","","",0,0,0,0,"","Board of Directors",0,0,"Helvetica,Geneva,Arial,SunSans-Regular,sans-serif","","#002ac5",0.8125,0,0,0,"white",0,0,0,0.1875,0.125,"",1,_,_,_,_,0,_,_,_,_,_,_,_,_,_,1,_,_,_,_,0,_,_,_,_,_,_,_,_,_);
pkg.aI("m27pbxyi","m27pbxyg",9.5625,1.0625,0.0625,1.1875,"Management Team","",/*URL*/"../../mi_sandbox_management_team.html","_self","","","",0,0,0,0,"","Management Team",1,1);
pkg.aI("m27pbxyj","m27pbxyg",9.5625,1.0625,0.0625,2.3125,"Board of Advisors","",/*URL*/"../../mi_sandbox_board_of_advisors.html","_self","","","",0,0,0,0,"","Board of Advisors",2,1);
/*f*/
__menuHolder.aP(pkg);
var __l=__br.un?"un.js":(__br.ie?"iedom.js":(__br.dom?"w3cdom.js":""));
document.write(_sTs+mmfolder+"core/"+__l+_sTe);
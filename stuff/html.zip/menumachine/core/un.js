//MenuMachine 2 (v2.2.1) Copyright 2007 Big Bang Software All Rights Reserved
if(typeof(unCalledFor)==_u){function menuPackage(){this.fr=this.aI=this.aB=this.action=this.hl=function(){}};___mh.prototype.aP=function(){};unCalledFor=1;}else{document.write('<a class="link" href="'+_gL(mmfolder+menuName+"/","navigation.html")+'">Site Navigation</a>\n');}

/*
MenuMachine 2 definition file - do not edit. http://menumachine.com
2.2.1 :: MI_sandbox_menu_3
*/
var menuName="mi_sandbox_menu_3";
var pkg=new menuPackage(menuName,0,0,0,0,0,1,0,0,1);
/*s*/
pkg.aB("m1eed6eb","",12.125,1.1875,0,0,0,0,0,0,0,0,0,"v",100,"",0.0625,0.0625,"white",0,"#910202",0,0,"#AAAAAA",0,0,0,"","","","",0,0,0,0,0,0,0,0,0);
pkg.aI("mbffd65d","m1eed6eb",12,1.0625,0.0625,0.0625,"Dr. John Librett, Ph.D., M.P.H.","","","_self","","","",0,0,0,0,"","Dr. John Librett, Ph.D., M.P.H.",0,0,"Helvetica,Geneva,Arial,SunSans-Regular,sans-serif","","#002ac5",0.8125,1,0,0,"white",0,0,0,0.1875,0.125,"",1,"","","#2b89b1",0.8125,1,0,0,"white",0,0,0,0.1875,0.125,"",1,"","","#002ac5",0.8125,1,0,0,"white",0,0,0,0.1875,0.125,"");
pkg.aB("ma68b57d","mbffd65d",9.4375,3.4375,12.125,0.0625,193,0,354,354,3,3,0,"v",100,"",0.0625,0.0625,"white",0,"#910202",0,0,"#AAAAAA",0,0,0,"","","","",0.625,0.625,0,0,0,0,0,0,0);
pkg.aI("m9ea43ec","ma68b57d",9.3125,1.0625,0.0625,0.0625,"About Me","",/*URL*/"../../mi_sandbox_about_dr_john_librett.html","_self","","","",0,0,0,0,"","About Me",0,0,"Helvetica,Geneva,Arial,SunSans-Regular,sans-serif","","#002ac5",0.8125,0,0,0,"white",0,0,0,0.3125,0.125,"",1,_,_,_,_,0,_,_,_,_,_,_,0.3125,_,_,1,_,_,_,_,0,_,_,_,_,_,_,0.3125,_,_);
pkg.aI("mbc892c9","ma68b57d",9.3125,1.0625,0.0625,1.1875,"About My Practice","",/*URL*/"../../mi_sandbox_about_my_practice_librett.html","_self","","","",0,0,0,0,"","About My Practice",1,0,"Helvetica,Geneva,Arial,SunSans-Regular,sans-serif","","#002ac5",0.8125,0,0,0,"white",0,0,0,0.3125,0.1875,"",1,_,_,_,_,_,_,_,_,_,_,_,_,0.1875,_,1,_,_,_,_,_,_,_,_,_,_,_,_,0.1875,_);
pkg.aI("m55b0867","ma68b57d",9.3125,1.0625,0.0625,2.3125,"Access My Patients","",/*URL*/"../../mi_sandbox_access_patients_librett.html","_self","","","",0,0,0,0,"","Access My Patients",2,1);
/*f*/
__menuHolder.aP(pkg);
var __l=__br.un?"un.js":(__br.ie?"iedom.js":(__br.dom?"w3cdom.js":""));
document.write(_sTs+mmfolder+"core/"+__l+_sTe);
/*
MenuMachine 2 definition file - do not edit. http://menumachine.com
2.2.1 :: MI_sandbox_menu_2
*/
var menuName="mi_sandbox_menu_2";
var pkg=new menuPackage(menuName,0,0,0,0,0,1,0,0,1);
/*s*/
pkg.aB("m9ba8216","",5.125,2.3125,0,0,0,0,0,0,0,0,0,"v",100,"",0.0625,0.0625,"white",0,"#910202",0,0,"#AAAAAA",0,0,0,"","","","",0,0,0,0,0,0,0,0,0);
pkg.aI("mc5c27b7","m9ba8216",5,1.0625,0.0625,0.0625,"Talk To Us","",/*URL*/"../../mi_sandbox_contact_us.html","_self","","","",0,0,0,0,"","Who We Are",0,0,"Helvetica,Geneva,Arial,SunSans-Regular,sans-serif","","#002ac5",0.8125,1,0,0,"white",0,0,0,0.1875,0.125,"",1,"","","#2b89b1",0.8125,1,0,0,"white",0,0,0,0.1875,0.125,"",1,"","","#002ac5",0.8125,1,0,0,"white",0,0,0,0.1875,0.125,"");
pkg.aI("m2babd6r","m9ba8216",5,1.0625,0.0625,1.1875,"Fine Print","","","_self","","","",0,0,0,0,"","Talk To Us",1,1);
pkg.aB("m2qhc8ch","m2babd6r",6.5625,3.4375,5.125,1.125,81,-1,98,98,3,3,1);
pkg.aI("m2qhc8ci","m2qhc8ch",6.4375,1.0625,0.0625,0.0625,"Legal","",/*URL*/"../../mi_sandbox_legal.html","_self","","","",0,0,0,0,"","Talk To Us",0,0,"Helvetica,Geneva,Arial,SunSans-Regular,sans-serif","","#002ac5",0.8125,0,0,0,"white",0,0,0,0.1875,0.125,"",1,_,_,_,_,0,_,_,_,_,_,_,_,_,_,1,_,_,_,_,0,_,_,_,_,_,_,_,_,_);
pkg.aI("m2qhc8cj","m2qhc8ch",6.4375,1.0625,0.0625,1.1875,"Privacy","",/*URL*/"../../mi_sandbox_privacy.html","_self","","","",0,0,0,0,"","Talk To Us",1,1);
pkg.aI("m2qhc8ck","m2qhc8ch",6.4375,1.0625,0.0625,2.3125,"Site Map","",/*URL*/"../../mi_sandbox_site_map.html","_self","","","",0,0,0,0,"","Talk To Us",2,1);
/*f*/
__menuHolder.aP(pkg);
var __l=__br.un?"un.js":(__br.ie?"iedom.js":(__br.dom?"w3cdom.js":""));
document.write(_sTs+mmfolder+"core/"+__l+_sTe);
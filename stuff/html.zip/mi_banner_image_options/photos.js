WPGgallery = new Object();
WPGgallery.name = "MI%20INDEX%20IMAGE%20OPTIONS%201";
WPGgallery.photographer = "heidi%20frieder%20:%20:%20art%20head%20:%20:%20903.519.2339";
WPGgallery.contact = "";
WPGgallery.email = "";
WPGgallery.date = "8/29/12"

WPGgallery.colors = new Object();
WPGgallery.colors.background = "#FFFFFF";
WPGgallery.colors.banner = "#FFFFFF";
WPGgallery.colors.text = "#000000";
WPGgallery.colors.link = "#002AC5";
WPGgallery.colors.alink = "#7E8BB8";
WPGgallery.colors.vlink = "#B8B9BE";

gPhotos = new Array();
gPhotos[0] = new Object();
gPhotos[0].filename = "mi_web_hed_im_1.jpg";
gPhotos[0].ImageWidth = 450;
gPhotos[0].ImageHeight = 83;
gPhotos[0].ThumbWidth = 75;
gPhotos[0].ThumbHeight = 13;
gPhotos[0].meta = new Object();

gPhotos[1] = new Object();
gPhotos[1].filename = "mi_web_hed_im_11.jpg";
gPhotos[1].ImageWidth = 450;
gPhotos[1].ImageHeight = 83;
gPhotos[1].ThumbWidth = 75;
gPhotos[1].ThumbHeight = 13;
gPhotos[1].meta = new Object();

gPhotos[2] = new Object();
gPhotos[2].filename = "mi_web_hed_im_12.jpg";
gPhotos[2].ImageWidth = 450;
gPhotos[2].ImageHeight = 83;
gPhotos[2].ThumbWidth = 75;
gPhotos[2].ThumbHeight = 13;
gPhotos[2].meta = new Object();

gPhotos[3] = new Object();
gPhotos[3].filename = "mi_web_hed_im_13.jpg";
gPhotos[3].ImageWidth = 450;
gPhotos[3].ImageHeight = 83;
gPhotos[3].ThumbWidth = 75;
gPhotos[3].ThumbHeight = 13;
gPhotos[3].meta = new Object();

gPhotos[4] = new Object();
gPhotos[4].filename = "mi_web_hed_im_2.jpg";
gPhotos[4].ImageWidth = 450;
gPhotos[4].ImageHeight = 83;
gPhotos[4].ThumbWidth = 75;
gPhotos[4].ThumbHeight = 13;
gPhotos[4].meta = new Object();

gPhotos[5] = new Object();
gPhotos[5].filename = "mi_web_hed_im_3.jpg";
gPhotos[5].ImageWidth = 450;
gPhotos[5].ImageHeight = 83;
gPhotos[5].ThumbWidth = 75;
gPhotos[5].ThumbHeight = 13;
gPhotos[5].meta = new Object();

gPhotos[6] = new Object();
gPhotos[6].filename = "mi_web_hed_im_4.jpg";
gPhotos[6].ImageWidth = 450;
gPhotos[6].ImageHeight = 83;
gPhotos[6].ThumbWidth = 75;
gPhotos[6].ThumbHeight = 13;
gPhotos[6].meta = new Object();

gPhotos[7] = new Object();
gPhotos[7].filename = "mi_web_hed_im_5.jpg";
gPhotos[7].ImageWidth = 450;
gPhotos[7].ImageHeight = 83;
gPhotos[7].ThumbWidth = 75;
gPhotos[7].ThumbHeight = 13;
gPhotos[7].meta = new Object();

gPhotos[8] = new Object();
gPhotos[8].filename = "mi_web_hed_im_6.jpg";
gPhotos[8].ImageWidth = 450;
gPhotos[8].ImageHeight = 83;
gPhotos[8].ThumbWidth = 75;
gPhotos[8].ThumbHeight = 13;
gPhotos[8].meta = new Object();

gPhotos[9] = new Object();
gPhotos[9].filename = "mi_web_hed_im_7.jpg";
gPhotos[9].ImageWidth = 450;
gPhotos[9].ImageHeight = 83;
gPhotos[9].ThumbWidth = 75;
gPhotos[9].ThumbHeight = 13;
gPhotos[9].meta = new Object();

gPhotos[10] = new Object();
gPhotos[10].filename = "mi_web_hed_im_8.jpg";
gPhotos[10].ImageWidth = 450;
gPhotos[10].ImageHeight = 83;
gPhotos[10].ThumbWidth = 75;
gPhotos[10].ThumbHeight = 13;
gPhotos[10].meta = new Object();

gPhotos[11] = new Object();
gPhotos[11].filename = "mi_web_hed_im_9.jpg";
gPhotos[11].ImageWidth = 450;
gPhotos[11].ImageHeight = 83;
gPhotos[11].ThumbWidth = 75;
gPhotos[11].ThumbHeight = 13;
gPhotos[11].meta = new Object();

